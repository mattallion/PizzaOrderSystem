import java.io.Serializable;
import java.util.ArrayList;
/**
 * This class constructs LineItem objects for orders of Pizza objects.
 * This class can also calculate the order's total cost, set a new number of Pizza objects,
 * generate a string type of the total order, and compare the costs of two orders.
 * @author Matthew
 * @see Pizza
 * @see IllegalPizza
 *
 */
public class LineItem implements Serializable, Comparable<LineItem> {

	/**
	 * 
	 */
	public static final long serialVersionUID = 1L;
	
	private final Pizza pizza;
	private int number;
	/**
	 * This constructor takes parameters and makes a LineItem object.
	 * If the parameters used result in an IllegalPizza order,
	 * the IllegalPizza exception is thrown
	 * @param numberIn The number of Pizza objects ordered in integer type.
	 * @param pizzaIn The Pizza object.
	 * @throws IllegalPizza If the number is either below 1 or greater than 100.
	 * @see IllegalPizza
	 * @see Pizza
	 */
	public LineItem(int numberIn, Pizza pizzaIn) throws IllegalPizza {
		this.pizza = pizzaIn;
		this.number = numberIn;
		if (this.number < 1 || this.number > 100)
			throw new IllegalPizza();
	}
	/**
	 * Defaults to a single Pizza for the LineItem order.
	 * Forces the number of Pizza objects ordered to equal 1.
	 * @param pizzaIn The Pizza object.
	 */
	public LineItem(Pizza pizzaIn) {
		this.pizza = pizzaIn;
		this.number = 1;
	}
	/**
	 * Returns the Pizza object for the current LineItem.
	 * @return The Pizza object for the current LineItem.
	 */
	public Pizza getPizza() {
		return this.pizza;
	}
	/**
	 * Returns the number of Pizza objects ordered for the current LineItem.
	 * @return The number of Pizza objects ordered for the current LineItem.
	 */
	public int getNumber() {
		return this.number;
	}
	/**
	 * Finds the total order cost for the LineItem.
	 * Retrieves a Pizza class type of the Pizza object in the LineItem.
	 * Uses the Pizza class method of getCost(), to retrieve the unit cost of the Pizza object.
	 * Multiplies the unit cost by the number of Pizza objects ordered.
	 * A discount is applied for certain bulk quantity orders.
	 * @return The total order cost.
	 * @see Pizza
	 * @see Pizza#getCost() getCost
	 * @see #getPizza()
	 * @see #getNumber()
	 */
	public float getCost() {
		float orderCost = 0f;
		Pizza pizza = getPizza();
		float unitCost = pizza.getCost();
		int number = getNumber();
		orderCost = unitCost * number;
		if (number >= 10 && number <= 20)
			orderCost = orderCost * 0.90f;
		if (number > 20)
			orderCost = orderCost * 0.85f;
		return orderCost;
	}
	/**
	 * Sets a new number for the LineItem.
	 * Changes the number attribute of the LineItem to equal the newNumber parameter.
	 * @param newNumber The new number of the LineItem object.
	 * @throws IllegalPizza If the number of Pizza objects ordered is less than 1 or greater than 100.
	 * @see IllegalPizza
	 */
	public void setNumber(int newNumber) throws IllegalPizza {
		this.number = newNumber;
		if (this.number < 1 || this.number > 100)
			throw new IllegalPizza();
	}
	/**
	 * Generates a string type of the whole order.
	 * This string type uses the Pizza class method of toString() to retrieve the pizzaString portion.
	 * This method combines the pizzaString portion with the number to generate the orderString.
	 * @return The string type of the complete order.
	 * @see Pizza#toString() toString
	 * @see #getPizza() getPizza
	 * @see #getNumber() getNumber
	 */
	public String toString() {
		String orderString = null;
		Pizza pizza = getPizza();
		String pizzaString = pizza.toString();
		int number = 0;
		number = getNumber();
		if (number < 10)
			orderString = " " + number + " " + pizzaString;
		else
			orderString = number + " " + pizzaString;
		return orderString;
	}
	/**
	 * This method compares the order costs of two different LineItem orders.
	 * If the cost of the parameter LineItem order is higher, the value of the comparison equals 1.
	 * If the cost of the current LineItem order is higher, the value of the comparison equals -1.
	 * If the costs are equal, the value of the comparison equals 0.
	 * 
	 * For the remainder of this method I was confused as to what the assignment was asking for.
	 * I didn't know if this was needed but this is what I thought:
	 * This method also creates an ArrayList of LineItems to correctly order the two LineItem orders.
	 * The larger order comes first in the ArrayList.
	 * @param The LineItem order to be compared.
	 * @return The value of the comparison.
	 * @throws IllegalPizza If an illegal Pizza object is generated during the method.
	 * @see IllegalPizza
	 * @see #getCost() getCost
	 * @see Pizza
	 * @see #getPizza() getPizza
	 * @see #getNumber() getNumber
	 * @see #LineItem(int, Pizza)
	 */
	public int compareTo(LineItem order2) {
		int compare = 0;
		float orderCost1 = order2.getCost();
		int cost1 = (int)Math.round(orderCost1);
		float orderCost2 = getCost();
		int cost2 = (int)Math.round(orderCost2);
		if (cost1 == cost2)
			compare = 0;
		else if (cost1 > cost2)
			compare = 1;
		else
			compare = -1;
		Pizza pizza1 = getPizza();
		int number1 = 0;
		number1 = getNumber();
		Pizza pizza2 = order2.getPizza();
		int number2 = 0;
		number2 = order2.getNumber();
		ArrayList<LineItem> twoOrders = new ArrayList<>();
		if (compare == 0) {
			try {
				twoOrders.add(new LineItem(number1, pizza1));
			} catch (IllegalPizza e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				twoOrders.add(new LineItem(number2, pizza2));
			} catch (IllegalPizza e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			try {
				twoOrders.add(new LineItem(number2, pizza2));
			} catch (IllegalPizza e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				twoOrders.add(new LineItem(number1, pizza1));
			} catch (IllegalPizza e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return compare;
	}
}