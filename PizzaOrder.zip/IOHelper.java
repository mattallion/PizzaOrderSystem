import java.util.Scanner;

public class IOHelper {
	public static String getString(String prompt) {
		System.out.println(prompt);
		Scanner scanner = new Scanner(System.in);
		String userInput = scanner.nextLine();
		return userInput;
	}
	public static int getInt(int min, String prompt, int max) {
		System.out.println(prompt);
		Scanner sc = new Scanner(System.in);
		int orderSize = sc.nextInt();
		if (orderSize < 1 || orderSize > 100) {
			System.out.println("Please enter a number between 1 and 100: ");
			getInt(min, prompt, max);
		}
		return orderSize;
	}
}