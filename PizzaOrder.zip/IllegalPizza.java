/**
 * This class extends the IllegalPizza exception.
 * @author Matthew
 *
 */
public class IllegalPizza extends Exception {
	/**
	 * Supplies a default message.
	 */
	public IllegalPizza() {
		super("Illegal Pizza Order!");
	}
	/**
	 * Passes along the message supplied to the exception.
	 * @param message A mores specific message.
	 */
	public IllegalPizza(String message) {
		super(message);
	}
}